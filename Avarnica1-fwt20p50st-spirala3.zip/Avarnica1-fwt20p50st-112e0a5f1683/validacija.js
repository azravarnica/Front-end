function validirajNaziv(ieNaziv) {
    const naziv = ieNaziv.value;
    if (naziv.length <= 5 && (/^[A-Z]{2,5}$/.test(naziv) || /^([A-Z]{2,}(\d))$/.test(naziv)))
        ieNaziv.style.backgroundColor = "#33ff33";
    else
        ieNaziv.style.backgroundColor = "#ff3333";
}

function validirajPocetak(iePocetak) {
    const pocetak = iePocetak.value;
    if (pocetak.length != 5) {
        iePocetak.style.backgroundColor = "#ff3333";
        return;
    }
    //["14","23"]
    const vrijemeNiz = pocetak.split(":");
    if (vrijemeNiz.length != 2) {
        iePocetak.style.backgroundColor = "#ff3333";
        return;
    }

    const sati = parseInt(vrijemeNiz[0]);
    const minute = parseInt(vrijemeNiz[1]);

    if (isNaN(sati) || isNaN(minute) || sati < 0 || sati > 23 || minute < 0 || minute > 59) {
        iePocetak.style.backgroundColor = "#ff3333";
        return;
    }

    const ukupnoMinute = 60 * sati + minute;
    if (ukupnoMinute >= 20 * 60) {
        iePocetak.style.backgroundColor = "#ff3333";
        return;
    }
    if (ukupnoMinute < 8 * 60) {
        iePocetak.style.backgroundColor = "#ff3333";
        return;
    }
    iePocetak.style.backgroundColor = "#33ff33";
}

function validirajKraj(iePocetak, ieKraj) {
    const kraj = ieKraj.value;
    if (kraj.length != 5) {
        ieKraj.style.backgroundColor = "#ff3333";
        return;
    }

    const vrijemeNiz = kraj.split(":");
    if (vrijemeNiz.length != 2) {
        ieKraj.style.backgroundColor = "#ff3333";
        return;
    }

    const sati = parseInt(vrijemeNiz[0]);
    const minute = parseInt(vrijemeNiz[1]);

    if (isNaN(sati) || isNaN(minute) || sati < 0 || sati > 23 || minute < 0 || minute > 59) {
        ieKraj.style.backgroundColor = "#ff3333";
        return;
    }

    const pocetak = iePocetak.value;

    if (pocetak >= kraj) {
        ieKraj.style.backgroundColor = "#ff3333";
    }
    else {
        ieKraj.style.backgroundColor = "#33ff33";
    }
}

function validirajTip(ieTip, iePocetak, ieKraj) {
    const tipAktivnosti = ieTip.value;
    const pocetak = iePocetak.value;
    const kraj = ieKraj.value;

    const pocetakNiz = pocetak.split(":");
    const krajNiz = kraj.split(":");

    const pocetakMinute = 60 * parseInt(pocetakNiz[0]) + parseInt(pocetakNiz[1]);
    const krajMinute = 60 * parseInt(krajNiz[0]) + parseInt(krajNiz[1]);
    const razlikaKrajPocetak = krajMinute - pocetakMinute;

    if (tipAktivnosti == "predavanje") {
        if (razlikaKrajPocetak >= 60 && razlikaKrajPocetak <= 3 * 60)
            ieTip.style.backgroundColor = "#33ff33";
        else
            ieTip.style.backgroundColor = "#ff3333";
    }

    if (tipAktivnosti == "vjezbe") {
        if (razlikaKrajPocetak >= 45 && razlikaKrajPocetak <= 3 * 60)
            ieTip.style.backgroundColor = "#33ff33";
        else
            ieTip.style.backgroundColor = "#ff3333";
    }
}



