FiltrirajRaspored.postaviRaspored($("#raspored"));

var inputi = [$("#nazivPredmetaUnos"),$("#tipAktivnostiUnos"),$("#vrijemeTrajanjaUnos"),$("#danUnos")]

$("#nazivPredmetaUnos").keypress(function (e) {
    for(let i=0;i<inputi.length;++i) {
        if(inputi[i][0].id != this.id)
            inputi[i].val("");
    }

    FiltrirajRaspored.filtrirajPredmet("")
});

$("#tipAktivnostiUnos").keypress(function (e) {
    for(let i=0;i<inputi.length;++i) {
        if(inputi[i][0].id != this.id)
            inputi[i].val("");
    }

    FiltrirajRaspored.filtrirajTip("")
});


$("#vrijemeTrajanjaUnos").keypress(function (e) {
    for(let i=0;i<inputi.length;++i) {
        if(inputi[i][0].id != this.id)
            inputi[i].val("");
    }

    FiltrirajRaspored.filtrirajTrajanje("")
});

$("#danUnos").keypress(function (e) {
    for(let i=0;i<inputi.length;++i) {
        if(inputi[i][0].id != this.id)
            inputi[i].val("");
    }

    FiltrirajRaspored.filtrirajBuduce("")
});



$("#filtrirajBtn").click(function(e) {
    var nazivPredmeta = $("#nazivPredmetaUnos").val();
    
    if(nazivPredmeta != "")  {
        FiltrirajRaspored.filtrirajPredmet(nazivPredmeta)
        return;
    } 

    var tipAktivnosti = $("#tipAktivnostiUnos").val();

    if(tipAktivnosti != "")  {
        FiltrirajRaspored.filtrirajTip(tipAktivnosti)
        return;
    } 

    var vrijemeTrajanja = $("#vrijemeTrajanjaUnos").val();

    if(vrijemeTrajanja != "") {
        FiltrirajRaspored.filtrirajTrajanje(vrijemeTrajanja);
        return;
    }

    var dan = $("#danUnos").val();
    var danPredix = dan[0];
    var danNaziv = dan.substr(1,dan.length);
    
    if(dan != "") {
        if(danPredix == "+")
            FiltrirajRaspored.filtrirajBuduce(danNaziv);
        else
            FiltrirajRaspored.filtrirajProslo(danNaziv);
    }
})