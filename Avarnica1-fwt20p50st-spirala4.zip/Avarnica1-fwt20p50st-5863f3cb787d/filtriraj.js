let FiltrirajRaspored = (function () {

    var raspored;
    var casovi;
    let indexNaziva = 0;
    let indexTipa = 1;
    let indexVremena = 2;

    function postaviRaspored(ref) {
        raspored = ref;
    }

    function filtrirajPredmet(nazivPredmeta) {
        if (raspored == undefined || raspored == null)
            console.log("raspored nije definisan");
        else if (nazivPredmeta == "" || nazivPredmeta.length == 0) {
            raspored.find(".cas").each(function (_, el) {
                el.style = "visibility:visible";
            });
        } else {
            raspored.find(".cas").each(function (_, el) {
                if (!(el.innerHTML.split("<br>")[indexNaziva].trim().toLowerCase().includes(nazivPredmeta.toLowerCase().trim())))
                    el.style = "visibility:hidden";
            });
        }
    }

    function filtrirajTip(nazivTipa) {
        if (raspored == undefined || raspored == null)
            console.log("raspored nije definisan");
        else if (nazivTipa == "" || nazivTipa.length == 0) {
            raspored.find(".cas").each(function (_, el) {
                el.style = "visibility:visible";
            });
        } else {
            raspored.find(".cas").each(function (_, el) {
                if (!(el.innerHTML.split("<br>")[indexTipa].trim().toLowerCase().includes(nazivTipa.toLowerCase().trim()))) {
                    el.style = "visibility:hidden";
                }
            });
        }
    }

    function filtrirajTrajanje(minute) {
        if (raspored == undefined || raspored == null)
            console.log("raspored nije definisan");
        else if (minute == 0) {
            raspored.find(".cas").each(function (_, el) {
                el.style = "visibility:visible";
            });
        } else {
            raspored.find(".cas").each(function (_, el) {
                let vrijeme = el.innerHTML.split("<br>")[indexVremena].trim().split("do")
                let pocetak = vrijeme[0].trim().split(":");
                let kraj = vrijeme[1].trim().split(":");

                let minutePocetak = +pocetak[0] * 60 + +pocetak[1];
                let minuteKraj = +kraj[0] * 60 + +kraj[1];

                if (minuteKraj - minutePocetak > minute)
                    el.style = "visibility:hidden";
            });
        }
    }

    function filtrirajProslo(dan) {
        if (raspored == undefined || raspored == null)
            console.log("raspored nije definisan");
        else if (dan == "ponedjeljak" || dan != "utorak" && dan != "srijeda" && dan != "cetvrtak" && dan != "petak") {
            $(".cas").each(function (_, el) {
                el.style = "visibility:visible"
            })
        } else {
            let index = -1;
            let redovi = raspored.find("tr");

            redovi.each(function (i, el) {
                if (index != 0) {
                    if (el.firstChild.nextSibling.innerHTML.toLowerCase() == dan.toLowerCase()) {
                        index = i;
                        return false;
                    }
                }
            });

            for (let i = index - 1; i > 0; --i) {
                let casovi = $(redovi[i]).find(".cas");

                if (casovi.length > 0) {
                    for (let i = 0; i < casovi.length; ++i)
                        casovi[i].style = "visibility:hidden"
                }
            }

            if (index == -1) {
                console.log("Dan nije nadjen");
                return;
            }

        }
    }

    function filtrirajBuduce(dan) {
        if (raspored == undefined || raspored == null)
            console.log("raspored nije definisan");
        else if (dan == "petak" || dan != "ponedjeljak" && dan != "utorak" && dan != "srijeda" && dan != "cetvrtak") {
            $(".cas").each(function (_, el) {
                el.style = "visibility:visible"
            })
        } else {
            let trebaSakrit = false;
            let redovi = raspored.find("tr");

            redovi.each(function (index, el) {
                if (index != 0) {
                    if (el.firstChild.nextSibling.innerHTML.toLowerCase() == dan.toLowerCase())
                        trebaSakrit = true;

                    if (trebaSakrit) {
                        let casovi = $(el).find(".cas");

                        if (casovi.length > 0) {
                            for (let i = 0; i < casovi.length; ++i)
                                casovi[i].style = "visibility:hidden"
                        }
                    }
                }
            });
        }
    }

    return {
        filtrirajPredmet: filtrirajPredmet,
        filtrirajTip: filtrirajTip,
        filtrirajTrajanje: filtrirajTrajanje,
        filtrirajProslo: filtrirajProslo,
        filtrirajBuduce: filtrirajBuduce,
        postaviRaspored: postaviRaspored,
    };
})();