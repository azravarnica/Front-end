const inputNaziv = document.getElementById("naziv")
inputNaziv.addEventListener("blur", function (e) {
    validirajNaziv(e.target)
});

const inputPocetak = document.getElementById("pocetak");
inputPocetak.addEventListener("blur", function (e) {
    validirajPocetak(e.target)
});


const inputKraj = document.getElementById("kraj");
inputKraj.addEventListener("blur", function (e) {
    validirajKraj(inputPocetak, e.target)
});

const inputAktivnost = document.getElementById("aktivnost");
inputAktivnost.addEventListener("blur", function (e) {
    validirajTip(e.target, inputPocetak, inputKraj)
});


