let assert = chai.assert;

// Testovi su pravljeni tako da broje one koji su sakriveni a ne da asserta predefinisane vrijednosti 
// kako bi se vise slucajeva moglo lakse testirati

function vrijemeUMinutamaIsto(vrijeme, minute) {
    vrijeme = vrijeme.split("do")
    let pocetak = vrijeme[0].trim().split(":");
    let kraj = vrijeme[1].trim().split(":");

    let minutePocetak = +pocetak[0] * 60 + +pocetak[1];
    let minuteKraj = +kraj[0] * 60 + +kraj[1];

    return minuteKraj - minutePocetak > minute;
}

describe('Test modula "FiltrirajRaspored"', function () {
    describe('Testovi za metodu filtrirajPredmet',
        function () {
            it('Test Case Sensitivity-a za aktivnost koja postoji', function () {

                FiltrirajRaspored.filtrirajPredmet("m");

                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[0].trim().toLowerCase().includes("m") == false) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajPredmet("");
            });

            it('Test naziva cijele aktivnosti', function () {

                FiltrirajRaspored.filtrirajPredmet("rma");

                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[0].trim().toLowerCase().includes("rma") == false) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajPredmet("");
            });

            it('Test ako se nalaze dvije aktivnosti sa istim slovima ali razlicitim pozicijama slova (RAM i RMA)', function () {

                FiltrirajRaspored.filtrirajPredmet("ram");

                let sakriveni1 = 0, sakriveni2 = 0, nesakriveni1 = 0, nesakriveni2 = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[0].trim().toLowerCase() == "ram") {
                        if (element.style.visibility == "hidden")
                            sakriveni1++;
                        else
                            nesakriveni1++;
                    }

                    if (element.innerHTML.split("<br>")[0].trim().toLowerCase() == "rma") {
                        if (element.style.visibility == "hidden")
                            sakriveni2++;
                        else
                            nesakriveni2++;
                    }
                })

                let sakrivenRam = sakriveni1 - nesakriveni1;
                let sakriveniRma = sakriveni2 - nesakriveni2;

                assert.notEqual(sakrivenRam, sakriveniRma);
                FiltrirajRaspored.filtrirajPredmet("");
            });
        });

    describe('Testovi za metodu filtrirajTip',
        function () {
            it('Test Case Sensitivity-a za tip koja postoji', function () {

                FiltrirajRaspored.filtrirajTip("vje");

                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[1].trim().includes("vje") == false) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajTip("");
            });

            it('Test kada tražimo tačno jedan tip aktivnosti', function () {

                FiltrirajRaspored.filtrirajTip("tutorijal");

                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[1].trim().includes("tutorijal") == false) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajTip("");
            });

            it('Test kada imamo više istih slova iz različitih aktivnosti ()', function () {

                FiltrirajRaspored.filtrirajTip("a");

                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (element.innerHTML.split("<br>")[1].trim().includes("a") == false) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajTip("");
            });
        });

    describe('Testovi za metodu filtrirajTrajanje',
        function () {
            it('Test ako je vrijeme trajanja 60 min', function () {

                FiltrirajRaspored.filtrirajTrajanje(60);
                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (vrijemeUMinutamaIsto(element.innerHTML.split("<br>")[2].trim(), 60)) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajTrajanje("");
            });

            it('Test ako je vrijeme trajanja 90 min', function () {

                FiltrirajRaspored.filtrirajTrajanje(90);
                let nesakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (vrijemeUMinutamaIsto(element.innerHTML.split("<br>")[2].trim(), 90)) {
                        if (element.style.visibility == "visible")
                            nesakriveni++;
                    }
                })

                assert.equal(nesakriveni, 0);
                FiltrirajRaspored.filtrirajTrajanje("")
            });

            it('Test ako je vrijeme trajanja 0 min', function () {

                FiltrirajRaspored.filtrirajTrajanje(0);
                let sakriveni = 0;

                $("#raspored").find(".cas").each(function (_, element) {
                    if (vrijemeUMinutamaIsto(element.innerHTML.split("<br>")[2].trim(), 90)) {
                        if (element.style.visibility == "hidden")
                            sakriveni++;
                    }
                })

                assert.equal(sakriveni, 0);
                FiltrirajRaspored.filtrirajTrajanje("")

            });
        });

    describe('Testovi za metodu filtrirajProslo ',
        function () {
            it('Test ako je dan Ponedjeljak (sve vidljivo)', function () {

                FiltrirajRaspored.filtrirajProslo("ponedjeljak");
                let sakrivenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i < 6) {
                        $(element).find(".cas").each(function (i, el) {
                            if (el.style.visibility == "hidden")
                                sakrivenih++;
                        })
                    }
                })

                assert.equal(sakrivenih, 0);
                FiltrirajRaspored.filtrirajProslo("");
            });

            it('Test ako je dan Srijeda (pola se ne vidi)', function () {

                FiltrirajRaspored.filtrirajProslo("srijeda");
                let sakrivenih = 0, pronadjenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i < 3) {
                        $(element).find(".cas").each(function (_, el) {
                            if (el.style.visibility == "hidden") sakrivenih++;
                            pronadjenih++;
                        })
                    }
                })

                assert.equal(sakrivenih, pronadjenih);
                FiltrirajRaspored.filtrirajProslo("");
            });

            it('Test ako je dan Petak (sve prije petka nije vidljivo)', function () {

                FiltrirajRaspored.filtrirajProslo("petak");
                let brojSakrivenih = 0;
                let pronadjenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i < 4) {
                        $(element).find(".cas").each(function (_, el) {
                            if (el.style.visibility == "hidden") brojSakrivenih++;
                            pronadjenih++;
                        })
                    }
                })

                assert.equal(brojSakrivenih, pronadjenih);
                FiltrirajRaspored.filtrirajProslo("");
            });

        });

    describe('Testovi za metodu filtrirajBuduce',
        function () {
            it('Test ako je dan Ponedjeljak (sve nije vidljivo)', function () {

                FiltrirajRaspored.filtrirajBuduce("ponedjeljak");
                let sakrivenih = 0, pronadjenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i <= 5) {
                        $(element).find(".cas").each(function (i, el) {
                            if (el.style.visibility == "hidden") sakrivenih++;
                            pronadjenih++;
                        })
                    }
                })

                assert.equal(sakrivenih, pronadjenih);
                FiltrirajRaspored.filtrirajBuduce("");
            });

            it('Test ako je dan Srijeda (pola se vidi) ', function () {

                FiltrirajRaspored.filtrirajBuduce("srijeda");
                let nesakrivenih = 0, pronadjenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i <= 2) {
                        $(element).find(".cas").each(function (i, el) {
                            if (el.style.visibility == "visible") nesakrivenih++;
                            pronadjenih++;
                        })
                    }
                })

                assert.equal(nesakrivenih, pronadjenih);
                FiltrirajRaspored.filtrirajBuduce("");
            });

            it('Test ako je dan Petak (sve vidljivo)', function () {

                FiltrirajRaspored.filtrirajBuduce("petak");
                let sakrivenih = 0;

                $("tr").each(function (i, element) {
                    if (i > 0 && i < 6) {
                        $(element).find(".cas").each(function (_, el) {
                            if (el.style.visibility == "visible") sakrivenih++;
                        })
                    }
                })

                assert.equal(sakrivenih, $(".cas").length);
                FiltrirajRaspored.filtrirajBuduce("");
            });
        });
});